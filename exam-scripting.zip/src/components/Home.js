import React, {useEffect, useState} from "react";
import "./styles.css";
import { Input } from "semantic-ui-react";

function Home() {
  const [timeRemaining, setTimeRemaining] = useState(600);


  useEffect(() => {
    const intervalId = setInterval(() => {
      setTimeRemaining(prevTime => prevTime - 1);
    }, 1000);

    return () => clearInterval(intervalId);
  }, []); 

  const formatTime = (seconds) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds < 10 ? '0' : ''}${remainingSeconds}`;
  };
  return (
    <React.Fragment>
      <section className="timer">
        <span> {formatTime(timeRemaining)} </span>
      </section>
      <section className="header">
        <div className="p-2">
          <h5> Cambridge IELTS 15Test 1-Passage 1</h5>
          <p>Read the text below and answer questions 1-13</p>
        </div>
      </section>

      <section className="py-2 container">
        <div className="content__display">
          <div className="questions">
            <h2 className="text-center">Nutmeg – a valuable spice</h2>
            <p>
              The nutmeg tree, Myristica fragrans, is a large evergreen tree
              native to Southeast Asia. Until the late 18th century, it only
              grew in one place in the world: a small group of islands in the
              Banda Sea, part of the Moluccas – or Spice Islands – in
              northeastern Indonesia. The tree is thickly branched with dense
              foliage of tough, dark green oval leaves, and produces small,
              yellow, bell-shaped flowers and pale yellow pear-shaped fruits.
              The fruit is encased in a fleshy husk. When the fruit is ripe,
              this husk splits into two halves along a ridge running the length
              of the fruit. Inside is a purple-brown shiny seed, 2–3 cm long by
              about 2 cm across, surrounded by a lacy red or crimson covering
              called an ‘aril’. These are the sources of the two spices nutmeg
              and mace, the former being produced from the dried seed and the
              latter from the aril.
            </p>
            <p>
              Nutmeg was a highly prized and costly ingredient in European
              cuisine in the Middle Ages, and was used as a flavouring,
              medicinal, and preservative agent. Throughout this period, the
              Arabs were the exclusive importers of the spice to Europe. They
              sold nutmeg for high prices to merchants based in Venice, but they
              never revealed the exact location of the source of this extremely
              valuable commodity. The Arab-Venetian dominance of the trade
              finally ended in 1512, when the Portuguese reached the Banda
              Islands and began exploiting its precious resources.
            </p>
            <p>
              Always in danger of competition from neighbouring Spain, the
              Portuguese began subcontracting their spice distribution to Dutch
              traders. Profits began to flow into the Netherlands, and the Dutch
              commercial fleet swiftly grew into one of the largest in the
              world. The Dutch quietly gained control of most of the shipping
              and trading of spices in Northern Europe. Then, in 1580, Portugal
              fell under Spanish rule, and by the end of the 16th century the
              Dutch found themselves locked out of the market. As prices for
              pepper, nutmeg, and other spices soared across Europe, they
              decided to fight back.
            </p>

            <p>
              In 1602, Dutch merchants founded the VOC, a trading corporation
              better known as the Dutch East India Company. By 1617, the VOC was
              the richest commercial operation in the world. The company had
              50,000 employees worldwide, with a private army of 30,000 men and
              a fleet of 200 ships. At the same time, thousands of people across
              Europe were dying of the plague, a highly contagious and deadly
              disease. Doctors were desperate for a way to stop the spread of
              this disease, and they decided nutmeg held the cure. Everybody
              wanted nutmeg, and many were willing to spare no expense to have
              it. Nutmeg bought for a few pennies in Indonesia could be sold for
              68,000 times its original cost on the streets of London. The only
              problem was the short supply. And that’s where the Dutch found
              their opportunity.
            </p>

            <p>
              The Banda Islands were ruled by local sultans who insisted on
              maintaining a neutral trading policy towards foreign powers. This
              allowed them to avoid the presence of Portuguese or Spanish troops
              on their soil, but it also left them unprotected from other
              invaders. In 1621, the Dutch arrived and took over. Once securely
              in control of the Bandas, the Dutch went to work protecting their
              new investment. They concentrated all nutmeg production into a few
              easily guarded areas, uprooting and destroying any trees outside
              the plantation zones. Anyone caught growing a nutmeg seedling or
              carrying seeds without the proper authority was severely punished.
              In addition, all exported nutmeg was covered with lime to make
              sure there was no chance a fertile seed which could be grown
              elsewhere would leave the islands. There was only one obstacle to
              Dutch domination. One of the Banda Islands, a sliver of land
              called Run, only 3 km long by less than 1 km wide, was under the
              control of the British. After decades of fighting for control of
              this tiny island, the Dutch and British arrived at a compromise
              settlement, the Treaty of Breda, in 1667. Intent on securing their
              hold over every nutmeg-producing island, the Dutch offered a
              trade: if the British would give them the island of Run, they
              would in turn give Britain a distant and much less valuable island
              in North America. The British agreed. That other island was
              Manhattan, which is how New Amsterdam became New York. The Dutch
              now had a monopoly over the nutmeg trade which would last for
              another century. Then, in 1770, a Frenchman named Pierre Poivre
              successfully smuggled nutmeg plants to safety in Mauritius, an
              island off the coast of Africa. Some of these were later exported
              to the Caribbean where they thrived, especially on the island of
              Grenada. Next, in 1778, a volcanic eruption in the Banda region
              caused a tsunami that wiped out half the nutmeg groves. Finally,
              in 1809, the British returned to Indonesia and seized the Banda
              Islands by force. They returned the islands to the Dutch in 1817,
              but not before transplanting hundreds of nutmeg seedlings to
              plantations in several locations across southern Asia.
              <p>The Dutch nutmeg monopoly was over.</p>
            </p>

            <p>
              Today, nutmeg is grown in Indonesia, the Caribbean, India,
              Malaysia, Papua New Guinea and Sri Lanka, and world nutmeg
              production is estimated to average between 10,000 and 12,000
              tonnes per year.
            </p>
          </div>

          <div className="questions">
            <h2>Questions 1–4</h2>
            <p>Complete the notes below.</p>
            <p>
              Choose <b>ONE WORD ONLY</b> from the passage for each answer.
              Write your answers in boxes 1–4 on your answer sheet.
            </p>

            <h3>The nutmeg tree and fruit</h3>
            <ol>
              <li>
                The leaves of the tree are
                <Input />
                in shape
              </li>
              <li>
                {" "}
                The
                <Input />
                surrounds the fruit and breaks open when the fruit is ripe
              </li>
              <li>
                The
                <Input />
                is used to produce the spice nutmeg
              </li>
              <li>
                The covering known as the aril is used to produce
                <Input />
              </li>
              <p>
              The tree has yellow flowers and fruit
              </p>
              <h2>Questions 5–7</h2>
              <p>
                Choose <b>TRUE</b> if the statement agrees with the information
                given in the text,.
              </p>
              <p>
                choose <b>FALSE</b> if the statement contradicts the
                information,or choose <b>NOT GIVEN</b> if there is no
                information on this.
              </p>
              
              <li>
                In the Middle Ages, most Europeans knew where nutmeg was grown.
                <br /><Input type="radio" />
                True <br />
                <Input type="radio" />
                False <br />
                <Input type="radio" />
                Not Given <br />
              </li>
              <li>
                The VOC was the world’s first major trading company.
                <br /> <Input type="radio" />
                True <br />
                <Input type="radio" />
                False <br />
                <Input type="radio" />
                Not Given <br />
              </li>
              <li>
                Following the Treaty of Breda, the Dutch had control of all the
                islands where nutmeg grew.
                <br /> <Input type="radio" />
                True <br />
                <Input type="radio" />
                False <br />
                <Input type="radio" />
                Not Given <br />
              </li>
              <h2>Questions 8–13</h2>
              <p>Complete the table below.</p>
              <p>
                Choose <b>ONE WORD ONLY</b> from the passage for each answer.
                Write your answers in boxes 8- 13 on your answer sheet.
              </p>
              <li>
                <h5>ONE WORD ONLY</h5>
                <p>
                  Nutmeg was brought to Europe by the <Input />{" "}
                </p>
              </li>
              <p>
                16th century European nations took control of the nutmeg trade
                17th century
              </p>
              <li>
                Demand for nutmeg grew, as it was believed to be effective
                against the disease known as the
                <Input />
              </li>
              <p>
                The Dutch –took control of the Banda Islands –restricted nutmeg
                production to a few areas
              </p>
              <li>
                Put
                <Input />
                on nutmeg to avoid it being cultivated outside the islands
              </li>
              <li>
                –finally obtained the island of <Input />
                from the British
              </li>
              <li>
                Late 18th century 1770 – nutmeg plants were secretly taken to{" "}
                <Input />
              </li>
              <li>
                1778 – half the Banda Islands’ nutmeg plantations were destroyed
                by a <Input />
              </li>
            </ol>
          </div>
        </div>
      </section>

      <section className="container">
        <div>
        <Input type="checkbox"/> Review
        </div>

        <nav aria-label="Page navigation example">
  <ul class="pagination justify-content-center">
    <li class="page-item">
      <a className="page-link" href="/" aria-label="Previous">
        <span aria-hidden="true">&laquo;</span>
      </a>
    </li>
    <li class="page-item"><a class="page-link" href="/">1</a></li>
    <li class="page-item"><a class="page-link" href="/">2</a></li>
    <li class="page-item"><a class="page-link" href="/">3</a></li>
    <li class="page-item"><a class="page-link" href="/">4</a></li>
    <li class="page-item"><a class="page-link" href="/">5</a></li>
    <li class="page-item"><a class="page-link" href="/">6</a></li>
    <li class="page-item">
      <a class="page-link" href="/" aria-label="Next">
        <span aria-hidden="true">&raquo;</span>
      </a>
    </li>
  </ul>
</nav>
      </section>
    </React.Fragment>
  );
}

export default Home;
