# Translator Script

### Overview
The Translator Script is a Python script that utilizes the Google Translate API through the googletrans library to translate text from one language to another. This script allows users to input text and specify the target language for translation.

### Features
Language code validation for both input and output languages.
Automatic language detection for the input text.
Translation of the input text to the specified target language.

### Prerequisites
Python 3.x

### Installation of the googletrans library.
run the command below:
`pip install googletrans==4.0.0-rc1`

### Usage
Run the script: python translator_script.py
Enter the text you want to translate when prompted.
Choose the target language for translation. You can use either the language code or the full name of the language.
The language code and lanaguage name will be printed as a look up after user has provided the input text.
The lookup has a format of "language code : language name" 
The script will output the translation result.


### Example
Enter the text you want to translate: Hello
Language codes look up: {'af': 'afrikaans', 'sq': 'albanian', ...}
To what language do you want to make the translation? It can be any of the above codes stated: fr

'Hello' has been translated from english to french as
Bonjour

### Notes
The script uses an unofficial Google Translate API, and there is no need for an API key.
Keep in mind that the googletrans library relies on web scraping and may be subject to changes in the structure of the Google Translate website.