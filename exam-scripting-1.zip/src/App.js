import logo from './logo.svg';
import Home from './components/Home';
import "semantic-ui-css/semantic.min.css";


function App() {
  return (
    <div >
      <Home/>
    </div>
  );
}

export default App;
