import React, { useEffect, useState } from "react";
import "./styles.css";
import { Button, Form, Input } from "semantic-ui-react";

function Home() {
  const [timeRemaining, setTimeRemaining] = useState(600);
  const [formData, setFormData] = useState({
    one: "",
    two: "",
    three: "",
    four: "",
    five: "",
    six: "",
    seven: "",
    eight: "",
    nine: "",
    ten: "",
    eleven: "",
    twelve: "",
    thirteen: "",
    fourteen: "",
    fifteen: "",
    sixteen: "",
    seventeen: "",
    eighteen: "",
    nineteen: "",
    twenty: "",
    twentyOne: "",
    twentyTwo: "",
    twentyThreeA: false,
    twentyThreeB: false,
    twentyThreeC: false,
    twentyThreeD: false,
    twentyThreeE: false,
    twentyFour: "",
    twentyFiveA: false,
    twentyFiveB: false,
    twentyFiveC: false,
    twentyFiveD: false,
    twentyFiveE: false,
    twentySix: "",
    twentySeven: "",
    twentyEight: "",
    twentyNine: "",
    thirty: "",
    thirtyOne: "",
    thirtyTwo: "",
    thirtyThree: "",
    thirtyFour: "",
    thirtyFive: "",
    thirtySix: "",
    thirtySeven: "",
    thirtyEight: "",
    thirtyNine: "",
    forty: "",
  });

  useEffect(() => {
    const intervalId = setInterval(() => {
      setTimeRemaining((prevTime) => prevTime - 1);
    }, 1000);

    return () => clearInterval(intervalId);
  }, []);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevFormData) => ({
      ...prevFormData,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(formData);
  };
  const formatTime = (seconds) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds < 10 ? "0" : ""}${remainingSeconds}`;
  };
  return (
    <React.Fragment>
      <section className="timer">
        <span> {formatTime(timeRemaining)} </span>
      </section>
      <section className="header">
        <div className="p-2">
          <h5> Cambridge IELTS 15Test 1-Passage 1</h5>
          <p>Read the text below and answer questions 1-13</p>
        </div>
      </section>

      <section className="py-2 container">
        <div className="content__display">
          <div className="questions">
            <h2 className="text-center">Nutmeg – a valuable spice</h2>
            <p>
              The nutmeg tree, Myristica fragrans, is a large evergreen tree
              native to Southeast Asia. Until the late 18th century, it only
              grew in one place in the world: a small group of islands in the
              Banda Sea, part of the Moluccas – or Spice Islands – in
              northeastern Indonesia. The tree is thickly branched with dense
              foliage of tough, dark green oval leaves, and produces small,
              yellow, bell-shaped flowers and pale yellow pear-shaped fruits.
              The fruit is encased in a fleshy husk. When the fruit is ripe,
              this husk splits into two halves along a ridge running the length
              of the fruit. Inside is a purple-brown shiny seed, 2–3 cm long by
              about 2 cm across, surrounded by a lacy red or crimson covering
              called an ‘aril’. These are the sources of the two spices nutmeg
              and mace, the former being produced from the dried seed and the
              latter from the aril.
            </p>
            <p>
              Nutmeg was a highly prized and costly ingredient in European
              cuisine in the Middle Ages, and was used as a flavouring,
              medicinal, and preservative agent. Throughout this period, the
              Arabs were the exclusive importers of the spice to Europe. They
              sold nutmeg for high prices to merchants based in Venice, but they
              never revealed the exact location of the source of this extremely
              valuable commodity. The Arab-Venetian dominance of the trade
              finally ended in 1512, when the Portuguese reached the Banda
              Islands and began exploiting its precious resources.
            </p>
            <p>
              Always in danger of competition from neighbouring Spain, the
              Portuguese began subcontracting their spice distribution to Dutch
              traders. Profits began to flow into the Netherlands, and the Dutch
              commercial fleet swiftly grew into one of the largest in the
              world. The Dutch quietly gained control of most of the shipping
              and trading of spices in Northern Europe. Then, in 1580, Portugal
              fell under Spanish rule, and by the end of the 16th century the
              Dutch found themselves locked out of the market. As prices for
              pepper, nutmeg, and other spices soared across Europe, they
              decided to fight back.
            </p>

            <p>
              In 1602, Dutch merchants founded the VOC, a trading corporation
              better known as the Dutch East India Company. By 1617, the VOC was
              the richest commercial operation in the world. The company had
              50,000 employees worldwide, with a private army of 30,000 men and
              a fleet of 200 ships. At the same time, thousands of people across
              Europe were dying of the plague, a highly contagious and deadly
              disease. Doctors were desperate for a way to stop the spread of
              this disease, and they decided nutmeg held the cure. Everybody
              wanted nutmeg, and many were willing to spare no expense to have
              it. Nutmeg bought for a few pennies in Indonesia could be sold for
              68,000 times its original cost on the streets of London. The only
              problem was the short supply. And that’s where the Dutch found
              their opportunity.
            </p>

            <p>
              The Banda Islands were ruled by local sultans who insisted on
              maintaining a neutral trading policy towards foreign powers. This
              allowed them to avoid the presence of Portuguese or Spanish troops
              on their soil, but it also left them unprotected from other
              invaders. In 1621, the Dutch arrived and took over. Once securely
              in control of the Bandas, the Dutch went to work protecting their
              new investment. They concentrated all nutmeg production into a few
              easily guarded areas, uprooting and destroying any trees outside
              the plantation zones. Anyone caught growing a nutmeg seedling or
              carrying seeds without the proper authority was severely punished.
              In addition, all exported nutmeg was covered with lime to make
              sure there was no chance a fertile seed which could be grown
              elsewhere would leave the islands. There was only one obstacle to
              Dutch domination. One of the Banda Islands, a sliver of land
              called Run, only 3 km long by less than 1 km wide, was under the
              control of the British. After decades of fighting for control of
              this tiny island, the Dutch and British arrived at a compromise
              settlement, the Treaty of Breda, in 1667. Intent on securing their
              hold over every nutmeg-producing island, the Dutch offered a
              trade: if the British would give them the island of Run, they
              would in turn give Britain a distant and much less valuable island
              in North America. The British agreed. That other island was
              Manhattan, which is how New Amsterdam became New York. The Dutch
              now had a monopoly over the nutmeg trade which would last for
              another century. Then, in 1770, a Frenchman named Pierre Poivre
              successfully smuggled nutmeg plants to safety in Mauritius, an
              island off the coast of Africa. Some of these were later exported
              to the Caribbean where they thrived, especially on the island of
              Grenada. Next, in 1778, a volcanic eruption in the Banda region
              caused a tsunami that wiped out half the nutmeg groves. Finally,
              in 1809, the British returned to Indonesia and seized the Banda
              Islands by force. They returned the islands to the Dutch in 1817,
              but not before transplanting hundreds of nutmeg seedlings to
              plantations in several locations across southern Asia.
              <p>The Dutch nutmeg monopoly was over.</p>
            </p>

            <p>
              Today, nutmeg is grown in Indonesia, the Caribbean, India,
              Malaysia, Papua New Guinea and Sri Lanka, and world nutmeg
              production is estimated to average between 10,000 and 12,000
              tonnes per year.
            </p>

            <div className="mt-5">
              <h2>IELTS 15Test 1-Passage 2</h2>
              <p>Read the text below and answer questions 14-26</p>
              <h4>Driverless cars</h4>
              <p>
                <b>A</b> The automotive sector is well used to adapting to
                automation in manufacturing. The implementation of robotic car
                manufacture from the 1970s onwards led to significant cost
                savings and improvements in the reliability and flexibility of
                vehicle mass production. A new challenge to vehicle production
                is now on the horizon and, again, it comes from automation.
                However, this time it is not to do with the manufacturing
                process, but with the vehicles themselves. Research projects on
                vehicle automation are not new. Vehicles with limited
                self-driving capabilities have been around for more than 50
                years, resulting in significant contributions towards driver
                assistance systems. But since Google announced in 2010 that it
                had been trialling self-driving cars on the streets of
                California, progress in this field has quickly gathered pace.
              </p>
              <p>
                <b>B</b> There are many reasons why technology is advancing so
                fast. One frequently cited motive is safety; indeed, research at
                the UK's Transport Research Laboratory has demonstrated that
                more than 90 percent of road collisions involve human error as a
                contributory factor, and it is the primary cause in the vast
                majority. Automation may help to reduce the incidence of this.
                Another aim is to free the time people spend driving for other
                purposes. If the vehicle can do some or all of the driving, it
                may be possible to be productive, to socialise or simply to
                relax while automation systems have responsibility for safe
                control of the vehicle. If the vehicle can do the driving, those
                who are challenged by existing mobility models – such as older
                or disabled travellers – may be able to enjoy significantly
                greater travel autonomy.
              </p>
              <p>
                <b>C</b> Beyond these direct benefits, we can consider the wider
                implications for transport and society, and how manufacturing
                processes might need to respond as a result. At present, the
                average car spends more than 90 percent of its life parked.
                Automation means that initiatives for car-sharing become much
                more viable, particularly in urban areas with significant travel
                demand. If a significant proportion of the population choose to
                use shared automated vehicles, mobility demand can be met by far
                fewer vehicles.
              </p>{" "}
              <p>
                <b>D</b> The Massachusetts Institute of Technology investigated
                automated mobility in Singapore, finding that fewer than 30
                percent of the vehicles currently used would be required if
                fully automated car sharing could be implemented. If this is the
                case, it might mean that we need to manufacture far fewer
                vehicles to meet demand. However, the number of trips being
                taken would probably increase, partly because empty vehicles
                would have to be moved from one customer to the next. Modelling
                work by the University of Michigan Transportation Research
                Institute suggests automated vehicles might reduce vehicle
                ownership by 43 percent, but that vehicles' average annual
                mileage would double as a result. As a consequence, each vehicle
                would be used more intensively, and might need replacing sooner.
                This faster rate of turnover may mean that vehicle production
                will not necessarily decrease.
              </p>{" "}
              <p>
                <b>E</b> Automation may prompt other changes in vehicle
                manufacture. If we move to a model where consumers are tending
                not to own a single vehicle but to purchase access to a range of
                vehicles through a mobility provider, drivers will have the
                freedom to select one that best suits their needs for a
                particular journey, rather than making a compromise across all
                their requirements. Since, for most of the time, most of the
                seats in most cars are unoccupied, this may boost production of
                a smaller, more efficient range of vehicles that suit the needs
                of individuals. Specialised vehicles may then be available for
                exceptional journeys, such as going on a family camping trip or
                helping a son or daughter move to university.
              </p>{" "}
              <p>
                X<b>G</b> There are a number of hurdles to overcome in
                delivering automated vehicles to our roads. These include the
                technical difficulties in ensuring that the vehicle works
                reliably in the infinite range of traffic, weather and road
                situations it might encounter; the regulatory challenges in
                understanding how liability and enforcement might change when
                drivers are no longer essential for vehicle operation; and the
                societal changes that may be required for communities to trust
                and accept automated vehicles as being a valuable part of the
                mobility landscape.
              </p>{" "}
              <p>
                <b>G</b> It's clear that there are many challenges that need to
                be addressed but, through robust and targeted research, these
                can most probably be conquered within the next 10 years.
                Mobility will change in such potentially significant ways and in
                association with so many other technological developments, such
                as telepresence and virtual reality, that it is hard to make
                concrete predictions about the future. However, one thing is
                certain: change is coming, and the need to be flexible in
                response to this will be vital for those involved in
                manufacturing the vehicles that will deliver future mobility.
              </p>
            </div>

            <div className="mt-5">
              <h2>IELTS 15Test 1-Passage 3</h2>
              <p>Read the text below and answer questions 27-40</p>
              <p>What is exploration?</p>

              <p>
                We are all explorers. Our desire to discover, and then share
                that new-found knowledge, is part of what makes us human –
                indeed, this has played an important part in our success as a
                species. Long before the first caveman slumped down beside the
                fire and grunted news that there were plenty of wildebeest over
                yonder, our ancestors had learnt the value of sending out scouts
                to investigate the unknown. This questing nature of ours
                undoubtedly helped our species spread around the globe, just as
                it nowadays no doubt helps the last nomadic Penan maintain their
                existence in the depleted forests of Borneo, and a visitor
                negotiate the subways of New York.
              </p>
              <p>
                Over the years, we've come to think of explorers as a peculiar
                breed – different from the rest of us, different from those of
                us who are merely 'well travelled', even; and perhaps there is a
                type of person more suited to seeking out the new, a type of
                caveman more inclined to risk venturing out. That, however,
                doesn't take away from the fact that we all have this enquiring
                instinct, even today; and that in all sorts of professions –
                whether artist, marine biologist or astronomer – borders of the
                unknown are being tested each day.
              </p>

              <p>
                Thomas Hardy set some of his novels in Egdon Heath, a fictional
                area of uncultivated land, and used the landscape to suggest the
                desires and fears of his characters. He is delving into matters
                we all recognise because they are common to humanity. This is
                surely an act of exploration, and into a world as remote as the
                author chooses. Explorer and travel writer Peter Fleming talks
                of the moment when the explorer returns to the existence he has
                left behind with his loved ones. The traveller 'who has for
                weeks or months seen himself only as a puny and irrelevant alien
                crawling laboriously over a country in which he has no roots and
                no background, suddenly encounters his other self, a relatively
                solid figure, with a place in the minds of certain people'.
              </p>
              <p>
                In this book about the exploration of the earth's surface, I
                have confined myself to those whose travels were real and who
                also aimed at more than personal discovery. But that still left
                me with another problem: the word 'explorer' has become
                associated with a past era. We think back to a golden age, as if
                exploration peaked somehow in the 19th century – as if the
                process of discovery is now on the decline, though the truth is
                that we have named only one and a half million of this planet's
                species, and there may be more than 10 million – and that's not
                including bacteria. We have studied only 5 per cent of the
                species we know. We have scarcely mapped the ocean floors, and
                know even less about ourselves; we fully understand the workings
                of only 10 per cent of our brains
              </p>

              <p>
                Here is how some of today's 'explorers' define the word. Ran
                Fiennes, dubbed the 'greatest living explorer', said, 'An
                explorer is someone who has done something that no human has
                done before – and also done something scientifically useful.'
                Chris Bonington, a leading mountaineer, felt exploration was to
                be found in the act of physically touching the unknown: 'You
                have to have gone somewhere new.' Then Robin Hanbury-Tenison, a
                campaigner on behalf of remote so-called 'tribal' peoples, said,
                'A traveller simply records information about some far-off
                world, and reports back; but an explorer changes the world.'
                Wilfred Thesiger, who crossed Arabia's Empty Quarter in 1946,
                and belongs to an era of unmechanised travel now lost to the
                rest of us, told me, 'If I'd gone across by camel when I could
                have gone by car, it would have been a stunt.' To him,
                exploration meant bringing back information from a remote place
                regardless of any great self-discovery.
              </p>

              <p>
                Each definition is slightly different – and tends to reflect the
                field of endeavour of each pioneer. It was the same whoever I
                asked: the prominent historian would say exploration was a thing
                of the past, the cutting-edge scientist would say it was of the
                present. And so on. They each set their own particular criteria;
                the common factor in their approach being that they all had,
                unlike many of us who simply enjoy travel or discovering new
                things, both a very definite objective from the outset and also
                a desire to record their findings.
              </p>
              <p>
                I'd best declare my own bias. As a writer, I'm interested in the
                exploration of ideas. I've done a great many expeditions and
                each one was unique. I've lived for months alone with isolated
                groups of people all around the world, even two 'uncontacted
                tribes'. But none of these things is of the slightest interest
                to anyone unless, through my books, I've found a new slant,
                explored a new idea. Why? Because the world has moved on. The
                time has long passed for the great continental voyages – another
                walk to the poles, another crossing of the Empty Quarter. We
                know how the land surface of our planet lies; exploration of it
                is now down to the details – the habits of microbes, say, or the
                grazing behaviour of buffalo. Aside from the deep sea and deep
                underground, it's the era of specialists. However, this is to
                disregard the role the human mind has in conveying remote
                places; and this is what interests me: how a fresh
                interpretation, even of a well-travelled route, can give its
                readers new insights.
              </p>
            </div>
          </div>

          <div className="questions">
            <Form onSubmit={handleSubmit}>
              <h2>Questions 1–4</h2>
              <p>Complete the notes below.</p>
              <p>
                Choose <b>ONE WORD ONLY</b> from the passage for each answer.
                Write your answers in boxes 1–4 on your answer sheet.
              </p>

              <h3>The nutmeg tree and fruit</h3>
              <ol>
                <li>
                  The leaves of the tree are
                  <Input
                    value={formData.one}
                    name="one"
                    onChange={handleInputChange}
                  />
                  in shape
                </li>
                <li>
                  {" "}
                  The
                  <Input
                    value={formData.two}
                    name="two"
                    onChange={handleInputChange}
                  />
                  surrounds the fruit and breaks open when the fruit is ripe
                </li>
                <li>
                  The
                  <Input
                    value={formData.three}
                    name="three"
                    onChange={handleInputChange}
                  />
                  is used to produce the spice nutmeg
                </li>
                <li>
                  The covering known as the aril is used to produce
                  <Input
                    value={formData.four}
                    name="four"
                    onChange={handleInputChange}
                  />
                </li>
                <p>The tree has yellow flowers and fruit</p>
                <h2>Questions 5–7</h2>
                <p>
                  Choose <b>TRUE</b> if the statement agrees with the
                  information given in the text,.
                </p>
                <p>
                  choose <b>FALSE</b> if the statement contradicts the
                  information,or choose <b>NOT GIVEN</b> if there is no
                  information on this.
                </p>
                <li>
                  In the Middle Ages, most Europeans knew where nutmeg was
                  grown.
                  <br />
                  <Input
                    type="radio"
                    name="five"
                    value="true"
                    checked={formData.five === "true"}
                    onChange={handleInputChange}
                  />
                  True <br />
                  <Input
                    type="radio"
                    name="five"
                    value="false"
                    checked={formData.five === "false"}
                    onChange={handleInputChange}
                  />
                  False <br />
                  <Input
                    type="radio"
                    name="five"
                    value="not given"
                    checked={formData.five === "not given"}
                    onChange={handleInputChange}
                  />
                  Not Given <br />
                </li>
                <li>
                  The VOC was the world’s first major trading company.
                  <br />{" "}
                  <Input
                    type="radio"
                    name="six"
                    value="true"
                    checked={formData.six === "true"}
                    onChange={handleInputChange}
                  />
                  True <br />
                  <Input
                    type="radio"
                    name="six"
                    value="false"
                    checked={formData.six === "false"}
                    onChange={handleInputChange}
                  />
                  False <br />
                  <Input
                    type="radio"
                    name="six"
                    value="not given"
                    checked={formData.six === "not given"}
                    onChange={handleInputChange}
                  />
                  Not Given <br />
                </li>
                <li>
                  Following the Treaty of Breda, the Dutch had control of all
                  the islands where nutmeg grew.
                  <br />{" "}
                  <Input
                    type="radio"
                    name="seven"
                    value="true"
                    checked={formData.seven === "true"}
                    onChange={handleInputChange}
                  />
                  True <br />
                  <Input
                    type="radio"
                    name="seven"
                    value="false"
                    checked={formData.seven === "false"}
                    onChange={handleInputChange}
                  />
                  False <br />
                  <Input
                    type="radio"
                    name="seven"
                    value="not given"
                    checked={formData.seven === "not given"}
                    onChange={handleInputChange}
                  />
                  Not Given <br />
                </li>
                <h2>Questions 8–13</h2>
                <p>Complete the table below.</p>
                <p>
                  Choose <b>ONE WORD ONLY</b> from the passage for each answer.
                  Write your answers in boxes 8- 13 on your answer sheet.
                </p>
                <li>
                  <h5>ONE WORD ONLY</h5>
                  <p>
                    Nutmeg was brought to Europe by the{" "}
                    <Input
                      value={formData.eight}
                      name="eight"
                      onChange={handleInputChange}
                    />{" "}
                  </p>
                </li>
                <p>
                  16th century European nations took control of the nutmeg trade
                  17th century
                </p>
                <li>
                  Demand for nutmeg grew, as it was believed to be effective
                  against the disease known as the
                  <Input
                    value={formData.nine}
                    name="nine"
                    onChange={handleInputChange}
                  />
                </li>
                <p>
                  The Dutch –took control of the Banda Islands –restricted
                  nutmeg production to a few areas
                </p>
                <li>
                  Put
                  <Input
                    value={formData.ten}
                    name="ten"
                    onChange={handleInputChange}
                  />
                  on nutmeg to avoid it being cultivated outside the islands
                </li>
                <li>
                  –finally obtained the island of{" "}
                  <Input
                    value={formData.eleven}
                    name="eleven"
                    onChange={handleInputChange}
                  />
                  from the British
                </li>
                <li>
                  Late 18th century 1770 – nutmeg plants were secretly taken to{" "}
                  <Input
                    value={formData.twelve}
                    name="twelve"
                    onChange={handleInputChange}
                  />
                </li>
                <li>
                  1778 – half the Banda Islands’ nutmeg plantations were
                  destroyed by a{" "}
                  <Input
                    value={formData.thirteen}
                    name="thirteen"
                    onChange={handleInputChange}
                  />
                </li>
                <h5>Questions 14–18</h5>
                <p>
                  {" "}
                  Reading Passage 2 has seven sections, <b>A–G.</b>
                </p>
                <p>Which section contains the following information?</p>
                <p>
                  Write the correct letter, A–G, in boxes 14–18 on your answer
                  sheet.
                </p>
                <table class="table table-bordered">
                  <thead>
                    <tr>
                      <th scope="col">Column</th>
                      <th scope="col">A</th>
                      <th scope="col">B</th>
                      <th scope="col">C</th>
                      <th scope="col">D</th>
                      <th scope="col">E</th>
                      <th scope="col">F</th>
                      <th scope="col">G</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <li>
                        <th scope="row">
                          reference to the amount of time when a car is not in
                          use
                        </th>
                      </li>
                      <th></th>
                      <th></th>
                      <th></th>
                      <th></th>
                      <th></th>
                      <th></th>
                      <th></th>
                    </tr>
                    <tr>
                      <li>
                        <th scope="row">
                          mention of several advantages of driverless vehicles
                          for individual road-users{" "}
                        </th>
                      </li>
                      <th></th>
                      <th></th>
                      <th></th>
                      <th></th>
                      <th></th>
                      <th></th>
                      <th></th>
                    </tr>
                    <tr>
                      <li>
                        <th scope="row">
                          reference to the opportunity of choosing the most
                          appropriate vehicle for each trip
                        </th>
                      </li>
                      <th></th>
                      <th></th>
                      <th></th>
                      <th></th>
                      <th></th>
                      <th></th>
                      <th></th>
                    </tr>

                    <tr>
                      <li>
                        <th scope="row">
                          an estimate of how long it will take to overcome a
                          number of problems
                        </th>
                      </li>
                      <th></th>
                      <th></th>
                      <th></th>
                      <th></th>
                      <th></th>
                      <th></th>
                      <th></th>
                    </tr>

                    <tr>
                      <li>
                        <th scope="row">
                          a suggestion that the use of driverless cars may have
                          no effect on the number of vehicles manufactured{" "}
                        </th>
                      </li>
                      <th></th>
                      <th></th>
                      <th></th>
                      <th></th>
                      <th></th>
                      <th></th>
                      <th></th>
                    </tr>
                  </tbody>
                </table>
                <h3> Questions 19–22</h3>
                <p>Complete the summary below.</p>
                <p>
                  Choose NO MORE THAN TWO WORDS from the passage for each
                  answer.
                </p>
                <p>Write your answers in boxes 19–22 on your answer sheet.</p>
                <h3 className="text-center">The impact of driverless cars</h3>
                <p>
                  Figures from the Transport Research Laboratory indicate that
                  most motor accidents are partly due to{" "}
                  <Input
                    value={formData.nineteen}
                    name="nineteen"
                    onChange={handleInputChange}
                  />
                  , so the introduction of driverless vehicles will result in
                  greater safety. In addition to the direct benefits of
                  automation, it may bring other advantages. For example,
                  schemes for{" "}
                  <Input
                    value={formData.twenty}
                    name="twenty"
                    onChange={handleInputChange}
                  />
                  will be more workable, especially in towns and cities,
                  resulting in fewer cars on the road. According to the
                  University of Michigan Transportation Research Institute,
                  there could be a 43 percent drop in{" "}
                  <Input
                    value={formData.twentyOne}
                    name="twentyOne"
                    onChange={handleInputChange}
                  />
                  of cars. However, this would mean that the yearly{" "}
                  <Input
                    value={formData.twentyTwo}
                    name="twentyTwo"
                    onChange={handleInputChange}
                  />
                  of each car would, on average, be twice as high as it
                  currently is. This would lead to a higher turnover of
                  vehicles, and therefore no reduction in automotive
                  manufacturing.
                </p>

                <h3>Questions 23 and 24</h3>

                <p>Choose TWO letters, A–E.</p>

                <p>
                  Write the correct letters in boxes 23 and 24 on your answer
                  sheet.
                </p>

                <p>
                  <b> 23 - 24</b>
                  Which TWO benefits of automated vehicles does the writer
                  mention?
                </p>

                <div>
                  <p>
                    <Input
                      type="checkbox"
                      checked={formData.twentyThreeA}
                      name="twentyThreeA"
                      onChange={handleInputChange}
                    />{" "}
                    A. Car travellers could enjoy considerable cost savings.
                  </p>
                  <p>
                    <Input
                      type="checkbox"
                      checked={formData.twentyThreeB}
                      name="twentyThreeB"
                      onChange={handleInputChange}
                    />{" "}
                    B. It would be easier to find parking spaces in urban areas.
                  </p>{" "}
                  <p>
                    <Input
                      type="checkbox"
                      checked={formData.twentyThreeC}
                      name="twentyThreeC"
                      onChange={handleInputChange}
                    />{" "}
                    C. Travellers could spend journeys doing something other
                    than driving.
                  </p>{" "}
                  <p>
                    <Input
                      type="checkbox"
                      checked={formData.twentyThreeD}
                      name="twentyThreeD"
                      onChange={handleInputChange}
                    />{" "}
                    D. People who find driving physically difficult could travel
                    independently.
                  </p>{" "}
                  <p>
                    <Input
                      type="checkbox"
                      checked={formData.twentyThreeE}
                      name="twentyThreeE"
                      onChange={handleInputChange}
                    />{" "}
                    E. A reduction in the number of cars would mean a reduction
                    in pollution.
                  </p>
                </div>

                <h3>Questions 25 and 26</h3>
                <p>Choose TWO letters, A–E.</p>
                <p>
                  <b> 25 - 26</b>
                  Which TWO challenges to automated vehicle development does the
                  writer mention?
                </p>

                <div>
                  <p>
                    <Input
                      type="checkbox"
                      checked={formData.twentyFiveA}
                      name="twentyFiveA"
                      onChange={handleInputChange}
                    />
                    A.making sure the general public has confidence in automated
                    vehicles
                  </p>
                  <p>
                    <Input
                      type="checkbox"
                      checked={formData.twentyFiveB}
                      name="twentyFiveB"
                      onChange={handleInputChange}
                    />
                    B.managing the pace of transition from conventional to
                    automated vehicles
                  </p>{" "}
                  <p>
                    <Input
                      type="checkbox"
                      checked={formData.twentyFiveC}
                      name="twentyFiveC"
                      onChange={handleInputChange}
                    />{" "}
                    C.deciding how to compensate professional drivers who become
                    redundant
                  </p>{" "}
                  <p>
                    <Input
                      type="checkbox"
                      checked={formData.twentyFiveD}
                      name="twentyFiveD"
                      onChange={handleInputChange}
                    />{" "}
                    D.setting up the infrastructure to make roads suitable for
                    automated vehicles
                  </p>{" "}
                  <p>
                    <Input
                      type="checkbox"
                      checked={formData.twentyFiveE}
                      name="twentyFiveE"
                      onChange={handleInputChange}
                    />{" "}
                    E.getting automated vehicles to adapt to various different
                    driving conditions
                  </p>
                </div>

                <div className="mt-3">
                  <h2>Questions 27–32</h2>
                  <p>
                    {" "}
                    Choose the correct letter, <b>A, B, C or D.</b>
                  </p>

                  <p>
                    Write the correct letter in boxes 27–32 on your answer
                    sheet.
                  </p>

                  <p>
                    27 The writer refers to visitors to New York to illustrate
                    the point that
                  </p>

                  <div>
                    <p>
                      <Input
                        type="radio"
                        name="twentySeven"
                        value="A"
                        checked={formData.twentySeven === "A"}
                        onChange={handleInputChange}
                      />{" "}
                      A.exploration is an intrinsic element of being human.
                    </p>
                    <p>
                      <Input
                        type="radio"
                        name="twentySeven"
                        value="B"
                        checked={formData.twentySeven === "B"}
                        onChange={handleInputChange}
                      />{" "}
                      B.most people are enthusiastic about exploring. .
                    </p>{" "}
                    <p>
                      <Input
                        type="radio"
                        name="twentySeven"
                        value="C"
                        checked={formData.twentySeven === "C"}
                        onChange={handleInputChange}
                      />{" "}
                      C.exploration can lead to surprising results.
                    </p>{" "}
                    <p>
                      <Input
                        type="radio"
                        name="twentySeven"
                        value="D"
                        checked={formData.twentySeven === "D"}
                        onChange={handleInputChange}
                      />{" "}
                      D.most people find exploration daunting.
                    </p>{" "}
                  </div>

                  <p>
                    28 According to the second paragraph, what is the writer's
                    view of explorers?
                  </p>

                  <div>
                    <p>
                      <Input
                        type="radio"
                        name="twentyEight"
                        value="A"
                        checked={formData.twentyEight === "A"}
                        onChange={handleInputChange}
                      />{" "}
                      A. Their discoveries have brought both benefits and
                      disadvantages.
                    </p>
                    <p>
                      <Input
                        type="radio"
                        name="twentyEight"
                        value="B"
                        checked={formData.twentyEight === "B"}
                        onChange={handleInputChange}
                      />{" "}
                      B.Their main value is in teaching others.
                    </p>{" "}
                    <p>
                      <Input
                        type="radio"
                        name="twentyEight"
                        value="C"
                        checked={formData.twentyEight === "C"}
                        onChange={handleInputChange}
                      />
                      C.They act on an urge that is common to everyone.
                    </p>{" "}
                    <p>
                      <Input
                        type="radio"
                        name="twentyEight"
                        value="D"
                        checked={formData.twentyEight === "D"}
                        onChange={handleInputChange}
                      />{" "}
                      D.They tend to be more attracted to certain professions
                      than to others.
                    </p>{" "}
                  </div>

                  <p>
                    29 The writer refers to a description of Egdon Heath to
                    suggest that
                  </p>

                  <div>
                    <p>
                      <Input
                        type="radio"
                        name="twentyNine"
                        value="A"
                        checked={formData.twentyNine === "A"}
                        onChange={handleInputChange}
                      />{" "}
                      A.Hardy was writing about his own experience of
                      exploration.
                    </p>
                    <p>
                      <Input
                        type="radio"
                        name="twentyNine"
                        value="B"
                        checked={formData.twentyNine === "B"}
                        onChange={handleInputChange}
                      />{" "}
                      B.Hardy was mistaken about the nature of exploration.
                    </p>{" "}
                    <p>
                      <Input
                        type="radio"
                        name="twentyNine"
                        value="C"
                        checked={formData.twentyNine === "C"}
                        onChange={handleInputChange}
                      />{" "}
                      C.Hardy's aim was to investigate people's emotional
                      states.
                    </p>{" "}
                    <p>
                      <Input
                        type="radio"
                        name="twentyNine"
                        value="D"
                        checked={formData.twentyNine === "D"}
                        onChange={handleInputChange}
                      />{" "}
                      D.Hardy's aim was to show the attraction of isolation.
                    </p>{" "}
                  </div>

                  <p>
                    30 In the fourth paragraph, the writer refers to 'a golden
                    age' to suggest that
                  </p>

                  <div>
                    <p>
                      <Input
                        type="radio"
                        name="thirty"
                        value="A"
                        checked={formData.thirty === "A"}
                        onChange={handleInputChange}
                      />{" "}
                      A.the amount of useful information produced by exploration
                      has decreased.
                    </p>
                    <p>
                      <Input
                        type="radio"
                        name="thirty"
                        value="B"
                        checked={formData.thirty === "B"}
                        onChange={handleInputChange}
                      />{" "}
                      B.fewer people are interested in exploring than in the
                      19th century.
                    </p>{" "}
                    <p>
                      <Input
                        type="radio"
                        name="thirty"
                        value="C"
                        checked={formData.thirty === "C"}
                        onChange={handleInputChange}
                      />{" "}
                      C.recent developments have made exploration less exciting.
                    </p>{" "}
                    <p>
                      <Input
                        type="radio"
                        name="thirty"
                        value="D"
                        checked={formData.thirty === "D"}
                        onChange={handleInputChange}
                      />{" "}
                      D.we are wrong to think that exploration is no longer
                      necessary.
                    </p>{" "}
                  </div>

                  <p>
                    31 In the sixth paragraph, when discussing the definition of
                    exploration, the writer argues that
                  </p>

                  <div>
                    <p>
                      <Input
                        type="radio"
                        name="thirtyOne"
                        value="A"
                        checked={formData.thirtyOne === "A"}
                        onChange={handleInputChange}
                      />{" "}
                      A.people tend to relate exploration to their own
                      professional interests.
                    </p>
                    <p>
                      <Input
                        type="radio"
                        name="thirtyOne"
                        value="B"
                        checked={formData.thirtyOne === "B"}
                        onChange={handleInputChange}
                      />
                      B.certain people are likely to misunderstand the nature of
                      exploration.
                    </p>{" "}
                    <p>
                      <Input
                        type="radio"
                        name="thirtyOne"
                        value="C"
                        checked={formData.thirtyOne === "C"}
                        onChange={handleInputChange}
                      />{" "}
                      C.the generally accepted definition has changed over time.
                    </p>{" "}
                    <p>
                      <Input
                        type="radio"
                        name="thirtyOne"
                        value="D"
                        checked={formData.thirtyOne === "D"}
                        onChange={handleInputChange}
                      />{" "}
                      D.historians and scientists have more valid definitions
                      than the general public.
                    </p>{" "}
                  </div>

                  <p>
                    32 In the last paragraph, the writer explains that he is
                    interested in
                  </p>

                  <div>
                    <p>
                      <Input
                        type="radio"
                        name="thirtyTwo"
                        value="A"
                        checked={formData.thirtyTwo === "A"}
                        onChange={handleInputChange}
                      />{" "}
                      A.how someone's personality is reflected in their choice
                      of places to visit.
                    </p>
                    <p>
                      <Input
                        type="radio"
                        name="thirtyTwo"
                        value="B"
                        checked={formData.thirtyTwo === "B"}
                        onChange={handleInputChange}
                      />
                      B.the human ability to cast new light on places that may
                      be familiar.
                    </p>{" "}
                    <p>
                      <Input
                        type="radio"
                        name="thirtyTwo"
                        value="C"
                        checked={formData.thirtyTwo === "C"}
                        onChange={handleInputChange}
                      />{" "}
                      C.how travel writing has evolved to meet changing demands.
                    </p>{" "}
                    <p>
                      <Input
                        type="radio"
                        name="thirtyTwo"
                        value="D"
                        checked={formData.thirtyTwo === "D"}
                        onChange={handleInputChange}
                      />{" "}
                      D.the feelings that writers develop about the places that
                      they explore.
                    </p>{" "}
                  </div>

                  <h2 className="mt-3">Questions 33–37</h2>

                  <p>
                    Look at the following statements (Questions 33–37) and the
                    list of explorers below.
                  </p>
                  <p>Match each statement with the correct explorer, A–E.</p>
                  <p>
                    Write the correct letter, A–E, in boxes 33–37 on your answer
                    sheet.
                  </p>
                  <p>NB You may use any letter more than once.</p>
                  <p>
                    <Input
                      value={formData.thirtyThree}
                      name="thirtyThree"
                      onChange={handleInputChange}
                    />{" "}
                    He referred to the relevance of the form of transport used.
                  </p>
                  <p>
                    <Input
                      value={formData.thirtyFour}
                      name="thirtyFour"
                      onChange={handleInputChange}
                    />{" "}
                    He described feelings on coming back home after a long
                    journey.
                  </p>
                  <p>
                    <Input
                      value={formData.thirtyFive}
                      name="thirtyFive"
                      onChange={handleInputChange}
                    />{" "}
                    He worked for the benefit of specific groups of people.
                  </p>
                  <p>
                    <Input
                      value={formData.thirtySix}
                      name="thirtySix"
                      onChange={handleInputChange}
                    />{" "}
                    He did not consider learning about oneself an essential part
                    of exploration.
                  </p>
                  <p>
                    <Input
                      value={formData.thirtySeven}
                      name="thirtySeven"
                      onChange={handleInputChange}
                    />{" "}
                    He defined exploration as being both unique and of value to
                    others.
                  </p>
                </div>

                <div>
                  <h2> Questions 38–40 </h2>
                  <p>Complete the summary below.</p>
                  <p>
                    Choose <b>NO MORE THAN TWO WORDS</b> from the passage for
                    each answer.
                  </p>

                  <p>Write your answers in boxes 38–40 on your answer sheet.</p>

                  <h3 className="text-center">The writer's own bias</h3>

                  <p>
                    The writer has experience of a large number of{" "}
                    <Input
                      value={formData.thirtyEight}
                      name="thirtyEight"
                      onChange={handleInputChange}
                    />
                    , and was the first stranger that certain previously{" "}
                    <Input
                      value={formData.thirtyNine}
                      name="thirtyNine"
                      onChange={handleInputChange}
                    />
                    people had encountered. He believes there is no need for
                    further exploration of Earth's{" "}
                    <Input
                      value={formData.forty}
                      name="forty"
                      onChange={handleInputChange}
                    />
                    , except to answer specific questions such as how buffalo
                    eat.
                  </p>
                </div>
              </ol>

              <div className="mt-5">
                <Button primary content="Submit" />
              </div>
            </Form>
          </div>
        </div>
      </section>

      <section className="container">
        <div>
          <Input type="checkbox" /> Review
        </div>

        <nav aria-label="Page navigation example">
          <ul class="pagination justify-content-center">
            <li class="page-item">
              <a className="page-link" href="/" aria-label="Previous">
                <span aria-hidden="true">&laquo;</span>
              </a>
            </li>
            <li class="page-item">
              <a class="page-link" href="/">
                1
              </a>
            </li>
            <li class="page-item">
              <a class="page-link" href="/">
                2
              </a>
            </li>
            <li class="page-item">
              <a class="page-link" href="/">
                3
              </a>
            </li>
            <li class="page-item">
              <a class="page-link" href="/">
                4
              </a>
            </li>
            <li class="page-item">
              <a class="page-link" href="/">
                5
              </a>
            </li>
            <li class="page-item">
              <a class="page-link" href="/">
                6
              </a>
            </li>
            <li class="page-item">
              <a class="page-link" href="/" aria-label="Next">
                <span aria-hidden="true">&raquo;</span>
              </a>
            </li>
          </ul>
        </nav>
      </section>
    </React.Fragment>
  );
}

export default Home;
